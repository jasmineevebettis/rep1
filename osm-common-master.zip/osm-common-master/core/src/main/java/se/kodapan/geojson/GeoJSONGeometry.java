package se.kodapan.geojson;

/**
 * @author kalle
 * @since 2014-09-21 12:58
 */
public abstract class GeoJSONGeometry extends GeoJSONObject {
}
