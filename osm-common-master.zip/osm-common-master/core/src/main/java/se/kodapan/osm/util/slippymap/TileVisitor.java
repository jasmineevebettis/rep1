package se.kodapan.osm.util.slippymap;

/**
 * @author Karl Wettin <mailto:karl.wettin@kodapan.se>
 * @since 2018-11-28
 */
public interface TileVisitor {

  public void visit(Tile tile);

}
